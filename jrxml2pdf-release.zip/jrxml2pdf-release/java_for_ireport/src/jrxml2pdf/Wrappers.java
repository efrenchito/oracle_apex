package jrxml2pdf;

public class Wrappers {

    static int mod(int value, int modifier) 
    {
      return value % modifier;    
    }

}
